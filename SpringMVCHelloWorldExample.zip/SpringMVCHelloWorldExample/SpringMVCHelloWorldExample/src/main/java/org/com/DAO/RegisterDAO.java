package org.com.DAO;


import org.com.model.Register;


public interface RegisterDAO 
{
public void insert(Register register);
public void delete(Register register);
}
