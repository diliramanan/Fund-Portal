package org.com.DAO;

import org.com.model.Login;

public interface LoginDAO {

	public void insert(Login login);
	public void delete(Login login);
}
