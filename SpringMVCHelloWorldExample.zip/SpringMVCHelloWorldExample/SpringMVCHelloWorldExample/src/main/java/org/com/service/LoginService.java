package org.com.service;

import org.com.model.Login;

public interface LoginService {

	public String logindetails(Login login);
}
