package org.com.service;

import org.com.model.Register;
import org.springframework.stereotype.Service;


public interface RegisterService {

	public String registeruserDetails(Register register);
}
